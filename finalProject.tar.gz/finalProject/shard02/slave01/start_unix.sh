#!bin/bash/
java -jar Slave02_01.jar
 
