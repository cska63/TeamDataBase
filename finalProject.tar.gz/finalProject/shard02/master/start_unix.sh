#!bin/bash/
java -jar Master02.jar
 
