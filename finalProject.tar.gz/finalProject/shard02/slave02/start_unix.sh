#!bin/bash/
java -jar Slave02_02.jar
 
