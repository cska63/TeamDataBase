java -jar Balancer_Client.jar
