#!bin/bash/
java -jar Master01.jar
 
