#!bin/bash/
java -jar Slave01_01.jar
 
