#!bin/bash/
java -jar Slave01_02.jar
 
