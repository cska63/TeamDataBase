#!/bin/bash
java -cp '../classes:../lib/*' Main loadbalancer
