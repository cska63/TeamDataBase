#!/bin/bash
mkdir -p classes
javac -d classes -cp 'lib/*' src/*.java

