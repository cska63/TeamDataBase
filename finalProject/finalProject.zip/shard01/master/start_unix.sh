#!/bin/bash
java -cp '../../classes:../../lib/*' Main master 0
