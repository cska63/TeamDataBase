#!/bin/bash
java -cp '../../classes:../../lib/*' Main slave 0 0
