#!/bin/bash
java -cp '../../classes:../../lib/*' Main slave 1 1
